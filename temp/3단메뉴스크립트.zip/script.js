﻿{
    document.getElementById("nav01").innerHTML =
    "<ul id='menu'>" +
        "<li><a href='#'>PROFILE</a></li>" +
        "<li><a href='#'>THESIS</a></li>" +
        "<li><a href='#'>IMAGE PROCESSING</a></li>" +
        "<li><a href='#'>GALLERY</a>" +
            "<ul id='menu2'>" +
                "<li><a href='#'>PHOTO GALLERY</a></li>" +
                "<li><a href='#'>PAINTING GALLERY</a></li>" +
            "</ul>" + "</li>" +
        "<li><a href='#'>COLOR AND LIGHT</a></li>" +
        "<li><a href='#'>PHOTO ISSUE</a></li>" +
        "<li><a href='#'>GUESTBOOK</a></li>" +
    "</ul>";
}


